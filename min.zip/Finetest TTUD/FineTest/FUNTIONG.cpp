#include<iostream>
using namespace std;
int g(int n) {
	if (n == 1)
		return 1;
	if (n == 3)
		return 3;
	if (n % 2 == 0)
		return g(n/2);
	int k = n / 4;
	if (n % 4 == 1) {
			return 2 * g(2 * k + 1) - g(k);
	}
	if (n % 4 == 3)
		return 3 * g(2 * k + 1) - 2 * g(k);
}
int main() {
	int n;
	cout << "Nhap n = "; cin >> n;
	cout << "g(" << n << ") = " << g(n);
	return 0;
}