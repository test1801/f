#include<iostream>
#include<algorithm>
using namespace std;
const int n=5;
int batdau[]={1,2,4,5,6};
int ketthuc[]={2,4,6,7,8};
int monney[]={100,300,150,200,300};
bool sapxep(int i,int j){return monney[j]>monney[i];} 
int main(){
    int a[n];
    for(int i=0;i<n;i++){
        a[i]=i;
    }
    sort(a,a+n,sapxep);
    int chose[n];
    chose[0]=a[0];
    int tongtien=monney[a[0]];
    int index=1;
    for(int i=1;i<n;i++){
        if(batdau[a[i]] >= ketthuc[a[index-1]]){
            chose[index++]=a[i];
            tongtien+=monney[a[i]];
        }
    }
    cout<<"Danh sach duoc chon: ";
    for(int i=0;i<index;i++){
        cout<<chose[i]<<" ";
    }
    cout<<"\nTong tien nhan duoc: "<<tongtien;
    return 0;
}