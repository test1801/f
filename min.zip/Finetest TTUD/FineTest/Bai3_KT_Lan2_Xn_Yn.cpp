#include<bits/stdc++.h>
using namespace std;
void findNthTerm(int n);
int main(){
	int n;
	cout << "Nhap n = ";cin>>n;
	findNthTerm(n);
	return 0;
}
void findNthTerm(int n) {
    long long X = 1;  // G�n gi� tri X(0) = 1
    long long Y = 0;  // G�n gi� tri Y(0) = 0
    for (int i = 1; i <= n; i++) {
        long long newX = X + Y;
        long long newY = 3 * X + 2 * Y;
        X = newX;
        Y = newY;
    }
    cout <<"X("<<n<<") = "<<X<<endl;
    cout <<"Y("<<n<<") = "<<Y<<endl;
}

