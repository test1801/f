#include<iostream>
using namespace std;
int n, m;
int arr[1001];
void Xuat() {
	int sum = 0;
	for (int i = 1; i <= m; i++) {
		sum += arr[i];
	}
	if (sum == n) {
		cout << n << " = ";
		for (int i = 1; i <= m; i++) {
			if(i==m)
				cout << arr[i];
			else
				cout << arr[i] << "+";
		}
		cout << endl;
	}
}
void Try(int k) {
	if (k > m) {
		Xuat(); return;
	}
	for (int i = 1; i <= n; i++) {
		arr[k] = i;
		Try(k + 1);
	}
}
int main() {
	cout << "Nhap n = "; cin >> n;
	cout << "Nhap m = "; cin >> m;
	Try(1);
	return 0;
}