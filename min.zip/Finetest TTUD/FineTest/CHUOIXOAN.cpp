#include<iostream>
#include <algorithm>
using namespace std;
int main() {
	string w;
	cin >> w;
	string u = w;
	reverse(u.begin(), u.end());
	w= w.append(u);

	long long m, n;
	cin >> m;
	for (int i = 0; i < m; i++) {
		cin >> n;
		cout << w[n % w.length()] << endl;
	}
	return 0;
}