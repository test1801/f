#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
void ShowArray(int arr[], int n) {
	for (int i = 0; i < n; i++) {
		cout << arr[i] << " ";
	}
	cout << endl;
}
void BubbleSort(int arr[], int n, int type) {
	int temp;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n - 1 - i; j++) {
			if (arr[j] * type > arr[j + 1] * type) {
				temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}

		}
	}
}
int main() {
	freopen("input.txt", "r", stdin);
	int n;
	cin >> n;
	int cnt = 0;
	int arr[1001];
	for (int i = 0; i < n; i++) {
		cin >> arr[i];
	}
	int check = 0;
	BubbleSort(arr, n, 1);
	//ShowArray(arr, n);
	for (int i = 0; i < n; i++) {
		for (int j = i + 1; j < n; j++) {
			for (int k = j + 1; k < n; k++) {
				if (arr[j] - arr[i] != arr[k] - arr[j])
					continue;
				for (int l = k + 1; l < n; l++) {
					if (arr[l] - arr[k] != arr[k] - arr[j])
						continue;
					for (int m = l + 1; m < n; m++) {
						if (arr[m] - arr[l] == arr[l] - arr[k])
						{
							cnt++;
							if (arr[i] == 0 || arr[j] == 0 || arr[k] == 0 || arr[l] == 0 || arr[m] == 0) {

								check++;
								cout << check << ". " << arr[i] << " " << arr[j] << " " << arr[k] << " " << arr[l] << " " << arr[m] << endl;
							}
							else
								cout << arr[i] << "\t" << arr[j] << "\t" << arr[k] << "\t" << arr[l] << "\t" << arr[m] << endl;
						}

					}
				}
			}
		}
	}

	cout << cnt;
	return 0;
}