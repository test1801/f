#include<iostream>
#include<algorithm>
using namespace std;
int a[100];
int b[100];
int m, n;
int S(int p, int q) {
	if (p == 0 || q == 0)
		return 0;
	else if (a[p] == b[q])
		return S(p - 1, q - 1) + 1;
	else
		return max(S(p - 1, q), S(q, p - 1));
};
int main() {

	//freopen("input.txt", "r", stdin);
	cout << "Nhap m = "; cin >> m;
	for (int i = 0; i < m; i++) {
		cout << "a[" << i + 1 << "] = "; cin >> a[i];
	}
	cout << "Nhap n = "; cin >> n;
	for (int i = 0; i < n; i++) {
		cout << "b[" << i + 1 << "] = "; cin >> b[i];
	}
	cout <<"Do dai day con chung dai nhat : " << S(m, n);
	return 0;
}