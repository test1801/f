#include <iostream>
#include <map>
using namespace std;

map <long long,long long> G;
long long g(long long n)
{
  
 	if (n < 4) {
        G[n] = n;
    }
 	else if(G.count(n) == 0){
	    if(n % 4 == 0)
	    {
	      	G[n] = g(3 * n/ 4);
	  	}
	  	else if (n % 4 == 1){
	   		G[n] = g(3*(n-1)/4) + g(3*(n-1)/4 + 1);
	  	}
	  	else if (n % 4 == 2){
	   		G[n] = g(3*(n-2)/4) + g(3*(n-2)/4 + 2);
	  	}
	  	else{
	   		G[n] = g(3*(n-3)/4) + g(3*(n-3)/4 + 3);
	  	}
 	}
    return G[n];
}

int main(){
	 int n;
	 cout << "Nhap n = ";
	 cin >> n;
	 
	 cout << "g(" << n << ") = " << g(n);
}
