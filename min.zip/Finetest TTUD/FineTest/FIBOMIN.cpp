#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
long long Fibo(long long a, long long b, long long c, long long k) {
	//cout << c << endl;
	if (a > k)
		return a;
	else return Fibo(b, c, b + c, k);
}
long long Fibonaci(long long k) {
	if (k < 0)
		return 0;
	return Fibo(0, 1, 1, k);
}
int main() {
	long long k;
	cin >> k;
	cout << Fibonaci(k);
	return 0;
}