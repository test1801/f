#include <iostream>
#include <math.h>
using namespace std;
class Calc
{
public:
    int Y(int n)
    {
        if (n == 0)
            return 0;
        return 3 * X(n - 1) + 2 * Y(n - 1);
    }
    int X(int n)
    {
        if (n == 0)
            return 1;
        return X(n - 1) + Y(n - 1);
    }
};


int main()
{
    Calc c;
    int n;
    cout << "Nhap N = ";
    cin >> n;
    cout << "X(" << n << ") = " << c.X(n) << endl;
    cout << "Y(" << n << ") = " << c.Y(n);
    return 0;
}
