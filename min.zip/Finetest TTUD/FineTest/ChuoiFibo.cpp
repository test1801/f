#include<iostream>
#include<algorithm>
using namespace std;

int arr[100];
bool sapxep(int i, int j) { return arr[i] < arr[j]; }
int Min(int start,int end) {
	return min(Min(start, start + end / 2), Min((start + end) / 2 + 1, end);
}
int main() {
	int n;
	cout << "Nhap N: "; cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> arr[i];
	}
	sort(arr, arr + n, sapxep);
	cout << Min(0, n);
	return 0;
}