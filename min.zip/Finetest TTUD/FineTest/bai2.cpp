#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <algorithm>
using namespace std;
int n;
int A[101];//thoigian bat dau
int B[101];//thoigian ket thuc
int dd[101],e,cnt;
bool sapxep(int i, int j)
{
    return B[i] < B[j];
}
int main()
{
    freopen("input.txt","r",stdin);
    cout << "Nhap N = ";
    cin >> n;
    for (int i = 0; i < n; i++)
        dd[i] = i;
    sort(dd + 0, dd + n, sapxep);
    for (int i = 0; i < n; i++)
    {
        cin >> A[i] >> B[i];
    }

    cout<<"Day cac cuoc hop duoc bo tri: "<<dd[0];
    cnt=1;
    e=B[dd[0]];
    for(int i=1;i<n;i++){
        if(e<=A[dd[i]]){
            cout<<" "<<dd[i];
            cnt++;
        }
    }
    cout<<"\nTong so cuoc hop duoc bo tri: "<<cnt;
    return 0;
}