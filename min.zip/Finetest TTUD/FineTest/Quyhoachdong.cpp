#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<algorithm>
using namespace std;
int s[100];

bool comp(int a, int b)
{
	return (s[a] < s[b]);
}
int main() {
	freopen("input.txt", "r", stdin);
	int n;
	int a[100];
	cout << "Nhap n: "; cin >> n;
	for (int i = 0; i < n; i++) {
		cout << "a[" << i << "] = "; cin >> a[i];
	}
	s[0] = 1;
	for (int i = 1; i < n; i++) {
		if (s[i] + s[i - 1] > s[i])
			s[i] += s[i - 1];
	}
	int maxx = max(0,n);
	cout << "Max = " << maxx;
	return 0;
}