#include <iostream>
using namespace std;

const int MAX_N = 1001;
const int INF = 1e9;

int graph[MAX_N][MAX_N];
int values[MAX_N];
int dist[MAX_N];
int max_values[MAX_N];
bool processed[MAX_N];
int n, m;

int Dijkstra() {
    for (int i = 1; i <= n; ++i) {
        dist[i] = INF;
        max_values[i] = 0;
        processed[i] = false;
    }

    dist[1] = 0;
    max_values[1] = values[1];

    for (int count = 1; count <= n; ++count) {
        int u = -1;
        for (int i = 1; i <= n; ++i) {
            if (!processed[i] && (u == -1 || dist[i] < dist[u])) {
                u = i;
            }
        }

        if (u == -1 || dist[u] == INF) {
            break;
        }

        processed[u] = true;
        for (int v = 1; v <= n; ++v) {
            if (graph[u][v] != INF) {
                if (dist[v] > dist[u] + graph[u][v]) {
                    dist[v] = dist[u] + graph[u][v];
                    max_values[v] = max_values[u] + values[v];
                }
                else if (dist[v] == dist[u] + graph[u][v]) {
                    max_values[v] = max(max_values[v], max_values[u] + values[v]);
                }
            }
        }
    }

    if (dist[n] == INF) {
        return 0; // Kh?ng c? du?ng di t? 1 d?n n
    }
    else {
        return max_values[n]; // K?t qu? l? gi? tr? t?i da c? th? nh?n du?c
    }
}

void input() {
    cin >> n;

    for (int i = 1; i <= n; ++i) {
        cin >> values[i];
    }

    cin >> m;

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            graph[i][j] = INF;
        }
    }

    for (int i = 0; i < m; ++i) {
        int p, q, u;
        cin >> p >> q >> u;
        graph[p][q] = u;
        graph[q][p] = u; // ?? th? v? hu?ng
    }
}

int main() {
    input();
    int result = Dijkstra();
    cout << result << endl;
    return 0;
}

