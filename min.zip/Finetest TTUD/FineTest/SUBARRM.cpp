#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
const int MAX = 100;
int a[MAX];
int m, n;
int arr[1001];
int cnt = 0;
int sum = 0;
void gen(int k)
{
	if (k > n)
	{
		if (sum == m)
			cnt++;
		return;
	}
	a[k] = 0;
	gen(k + 1);
	a[k] = 1;
	sum += arr[k];
	if(sum<=m)
		gen(k + 1);
	sum -= arr[k];
}
int main() {
	//freopen("input.txt", "r", stdin);
	cout << "Nhap m = "; cin >> m;
	cout << "Nhap n = "; cin >> n;
	for (int i = 1; i <=n; i++) {
		cout << "a[" << i-1 << "] = "; cin >> arr[i];
	}
	gen(1);
	cout << "Co tat ca " << cnt << " cach phan tich.";
	return 0;
}