#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <set>
using namespace std;
int n;
const int MAX = 101;
int m[MAX][MAX];
set<int> v1, v2;
int dd[MAX];
int main()
{
    freopen("input.txt", "r", stdin);
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        dd[i] = 0;
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            cin >> m[i][j];
        }
    }
    v1.insert(1);
    dd[1] = 1;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (m[i][j] == 1)
            {
                if (dd[i] == 1)
                {
                    v2.insert(j);
                    dd[j] = 2;
                }
                else if (dd[i] == 2)
                {
                    v1.insert(j);
                    dd[j] = 1;
                }
            }
        }
    }
    bool flag = 0;
    for (int x1 : v1)
    {
        for (int x2 : v2)
        {
            if (x1 == x2)
            {
                flag = 1;
                break;
            }
        }
    }
    if (flag == 1)
    {
        cout << "Do thi Khong phai 2 phia";
    }
    else
    {
        cout << "Do thi 2 phia" << endl;
        cout << "V1 : ";
        
        for (int x : v1)
        {
            cout << x << " ";
        }
        cout << "\nV2: ";
        for (int x : v2)
        {
            cout << x << " ";
        }
    }

    return 0;
}
