#include<iostream>
#include<map>
using namespace std;

map<unsigned long long ,unsigned long long> a;

const long long mod = 1000000000;
unsigned long long poww(int a, int n)
{
	if (n == 0) return 1;
	if (n == 1) return a;
	unsigned long long k = poww(a, n/2);
	if (n%2 == 0) return k*k%mod;
	else return k*k*a%mod;
}
unsigned long long f(unsigned long long n){
	if(n==0) return a[n]=1;
	else if(a[n]!=0) return a[n];
		else return a[n] = ((poww(2,n)+f(n-1))%mod);
}
int main(){
    int n ;
	cin>>n;
	cout << f(n) << endl;
}
