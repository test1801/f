#include<bits/stdc++.h>
using namespace std;

map<long long,long long> F;

long long f(int n){
	F[1]=0;
	if(n<=1){
		return F[n];
	}else{
		if(n%2==0){
			if(F.count(n)==0){
				F[n]=1+f(n/2);
			}
		}
		if(n%2!=0){
			if(F.count(n)==0){
				F[n]=1+f(3*n+1);
			}
		}	
	}
	return F[n];
}

int main(){
	int n;
	cin>>n;
	cout<<f(n);
}
