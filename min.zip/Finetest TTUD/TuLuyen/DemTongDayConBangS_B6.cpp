#include<bits/stdc++.h>
using namespace std;

//int a[100] = {1,2,3,4,5,4,3,2},S=10,n=8;
int a[100],S,n;
int F(int sum,int i){
	if(sum == 0) return 1;		// Dieu kien duoc 1 cach
	if(sum < 0) return 0;
	// neu lon hon thi sua return thanh 1
	if(i<0) return 0;	// Het day
	return F(sum,i-1) + F(sum - a[i], i-1) ;
}

int main(){
	cout<<"Nhap S = ";
	cin>>S;
	cout<<"Nhap n = ";
	cin>>n;
	for(int i = 0;i<n;i++){
		cout<<"a["<<i<<"] = ";
		cin>>a[i];
	}
	cout<<"Co tat ca "<<F(S,n-1)<<" cach phan tich.";	
}

