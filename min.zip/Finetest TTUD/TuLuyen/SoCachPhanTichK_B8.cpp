#include<iostream>
using namespace std;
int n, cnt, a[100];
bool final = false;
void init(){
 	cnt=1;
 	a[1]=n;
 }
void gen(){
 	int i =cnt;
 	while (i>=1 && a[i]==1)
 		--i;
 	if (i==0)
 		final = true;
 	else{
 		a[i]--;
 		int tmp = cnt-i+1;
 		cnt=i;
 		int q = tmp/a[i],r=tmp%a[i];
 		for (int j =1; j<=q;j++){
 			a[++cnt] = a[i];
		 }
		if (r!=0){
			a[++cnt]=r;
		}
	 }
 }
bool check(int a[],int cnt, int k){
 	int res=1;
 	for (int i=1;i<=cnt;i++) res*=a[i];
 	return res>=k;
 }
 int main(){
 	int kk;
 	cin>>n>>kk;
 	init();
 	int dem =0;
 	while (!final){
 		if (check(a,cnt,kk)) dem++;
 		gen();
	 }
	 cout<<dem<<endl;
 }
