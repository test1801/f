#include<bits/stdc++.h>
using namespace std;

int a[100],n,sum =0,dem=0;

void Try(int k,int sum,int current){
	if(sum%3==0 && k ==3){
		dem++; return;
	}
	for(int i=current+1;i<n;i++){
		Try(k+1,sum+a[i],i);
	}
	
}

int main(){
	cin>>n;
	for(int i = 0;i<n;i++) cin>>a[i];
	Try(0,0,-1);
	cout<<"So cach chon: "<<dem;
}

