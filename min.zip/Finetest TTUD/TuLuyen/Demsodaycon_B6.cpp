#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
int cnt=0;
int a[101];
int k,n,sum=0;
int b[101];
// void Xuat(){
//     for(int j=0;j<n;j++){
//         if(b[j]==1)
//             cout<<a[j]<<" ";
//     }
//     cout<<endl;
// }
void Dem(int i){
    if(i>=n){
        if(sum>k){
            cnt++;
//             Xuat();
        }
        return;
    }
    b[i]=0;
    Dem(i+1);
    b[i]=1;
    sum+=a[i];
    Dem(i+1);
    sum-=a[i];
}
int main(){
//    freopen("input.txt","r",stdin);
    cin>>k>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    Dem(0);
    cout<<cnt;
    return 0;
}
