#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<int> exchange_coins(vector<int>& coins, int amount) {
    sort(coins.rbegin(), coins.rend());
	
    vector<int> exchange_coins(coins.size(), 0);

    for (int i = 0; i < coins.size(); i++) {
        exchange_coins[i] = amount / coins[i];
        amount -= exchange_coins[i] * coins[i];
    }
    return exchange_coins;
}

int main() {
    int n, amount;
    cout << "Nhap so loai tien xu: ";
    cin >> n;

    vector<int> coins(n);
    cout << "Nhap gia tri moi loai tien xu: "<<endl;
    for (int i = 0; i < n; i++) {
    	cout<<"Nhap tien "<<i+1<<": ";
        cin >> coins[i];
    }

    cout << "So tien can doi: ";
    cin >> amount;
    
    int count = 0;

    vector<int> result = exchange_coins(coins, amount);

    cout << "Phuong an doi tien: "<<endl;
    for (int i = 0; i < result.size(); i++) {
    	count += result[i];
        cout << result[i] << " dong "<<coins[i] <<endl;
    }
	cout<<"\nTong so dong tien doi duoc: "<<count;
    return 0;
}
