#include<iostream>
using namespace std; 
int n;
int arr[1001];
int sum = 0;
bool Check(int k){
	if (sum == n) {
		cout << n << " = " << arr[1];
		for (int i = 2; i <= k; i++) {
			cout <<"+" << arr[i];
		}
		cout << endl;
		return true;
	}
	return false;
}

void Try(int k,int next) {
	for (int i = next; i > 0; i--,sum-=arr[k]) {
		arr[k]=i;
		sum += arr[k];
		if(Check(k)) continue;
		if(k<n)
			Try(k+1,i);
	}
}

int main() {
	cout << "Nhap n = "; cin >> n;
	Try(1,n);
	return 0;
}
