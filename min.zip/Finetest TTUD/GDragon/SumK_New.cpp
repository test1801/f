#include <iostream>
using namespace std;

const int MAX = 1000;
int k, a[MAX][MAX];

void Sum(int k) {
	for (int i = 1; i <= k; i++) {
		for (int j = 1; j <= k; j++) {
			if (i == j) a[i][j] = a[i-1][j] + 1;
			else if (i < j) a[i][j] = a[i-1][j] + a[i-1][j-i];
			else a[i][j] = a[i-1][j];
		}
	}
}

int main() {
	cout << "Nhap k = "; cin >> k;
	Sum(k);
	cout << "Co tat ca " << a[k][k] - 1<< " cach phan tich.";
}
