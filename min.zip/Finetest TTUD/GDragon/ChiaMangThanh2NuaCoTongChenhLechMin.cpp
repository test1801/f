#include<bits/stdc++.h>
using namespace std;

void xuat(int a[],int p,int q){
	for(int i = p; i<=q;i++){
		if(i==q){
			cout<<a[i];
		}else{
			cout<<a[i]<<", ";
		}
	}
}

int main(){
	int n;
	cout<<"Nhap so phan tu day A: "; cin>>n;
	int a[n];
	cout<<"Nhap mang: "<<endl;
	for(int i = 1; i<=n;i++){
		cout<<"a["<<i<<"] = ";
		cin>>a[i];
	}
	
	int p,q;
	int sumleft = 0, sumright;;
	int min = 99999;
	cout<<"Nhap p: "; cin>>p;
	cout<<"Nhap q: "; cin>>q;
	int sumtotal = 0;
	for(int i = p; i<=q;i++){
		sumtotal += a[i];
	}
	int index;
	for(int i = p; i<=q-1;i++){
		sumleft += a[i];
		if(abs(sumleft - (sumtotal-sumleft))<min){
			min = abs(sumleft - (sumtotal-sumleft));
			index = i;
		}
	}
	cout<<"Ket qua la: "<<min
	<<" (chia thanh 2 nua [";
	xuat(a,p,index);
	cout<<"] va [";
	xuat(a,index+1,q);
	cout<<"])";

	
}
