#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cout<<"Nhap so luong phan tu: ";cin>>n;
	int a[n];
	
	for(int i=0;i<n;i++){
		cout<<"Nhap phan tu thu "<<i+1<<": ";
		cin>>a[i];
	}
	int m;
	cout<<"Nhap so m: ";
	cin>>m;
	int count=0;
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if(a[i]*a[j]>m && a[i] != a[j]){
				cout<<a[i]<<";"<<a[j];
			}
		}
	}
	cout<<"\nSo cap phan tu co tich lon hon m la: "<<count;
}
