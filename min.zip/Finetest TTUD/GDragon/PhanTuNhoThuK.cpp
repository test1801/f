#include <iostream>

using namespace std;

int main() {
    int n, k, count;
    cout << "Nhap so phan tu cua day N = ";
    cin >> n;
    vector<int> a(n);
    cout << "Nhap cac phan tu cua day:\n";
    for(int i = 1; i < n; i++) {
    	cout<<"A["<<i<<"] = ";
        cin >> a[i];
    }
    int min = a[1];
    int gt;
    for(int i = 2; i < n; i++){
    	if(a[i]<min){
    		min = a[i];
		}
	}
	do{
		cout<<"Nhap K (0<=K<N): "; cin>>k;
	} while(k<=0 || k>=n);
	for (int i = 1; i < n; i++) {
        if (a[i] > min) {
            count++;
            if (count == k) {
            	cout<<"Phan tu nho thu "<<k<<" la: "<<a[i];
                break;
            }
        }
    }
    return 0;
}

