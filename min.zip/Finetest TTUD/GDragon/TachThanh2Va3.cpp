#include<bits/stdc++.h>
using namespace std;

int n,a[100], dem = 0;
int sum = 0;

int main(){
	cin>>n;
	a[1] = 0;
	a[2] = 1;
	a[3] = 1;
	for(int i=4;i<=n;i++){
		a[i] = a[i-2] + a[i-3];
	}
	cout<<a[n];
}

