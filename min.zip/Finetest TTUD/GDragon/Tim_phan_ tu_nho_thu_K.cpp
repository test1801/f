#include <bits/stdc++.h>

using namespace std;



int main() {
    int n, k, count;
    cout << "Nhap so phan tu cua day N = ";
    cin >> n;
    vector<int> a(n);
    cout << "Nhap cac phan tu cua day:\n";
    for(int i = 1; i <= n; i++) {
    	cout<<"A["<<i<<"] = ";
        cin >> a[i];
    }
    int min = a[1];
    int gt;
    for(int i = 2; i <= n; i++){		// tim min
    	if(a[i]<min){
    		min = a[i];
		}
	}
	cout<<min<<endl;
	
	
	do{
		cout<<"Nhap K (0<K<N): "; cin>>k;
	} while(k<=0 || k>=n);
	for (int i = 1; i <= n; i++) {
        if (a[i] > min) {
            count++;
            if (count == k) {
            	cout<<"Phan tu nho thu "<<k<<" la: "<<a[i];
                break;
            }
        }
    }
    return 0;
}



//using namespace std;
//
//int main() {
//    int N, K;
//    cout << "Nhap so phan tu cua day N = ";
//    cin >> N;
//    vector<int> A(N);
//    cout << "Nhap cac phan tu cua day:\n";
//    for(int i = 0; i < N; i++) {
//    	cout<<"A["<<i<<"] = ";
//        cin >> A[i];
//    }
//    sort(A.begin(), A.end());
//    unique(A.begin(), A.end());		// xoa nhung phan tu bi trung
////    for(int i = 0; i < N; i++) {
////    	cout<<A[i];
////    }
////    cout<<endl;
//    do{
//		cout<<"Nhap K (0<=K<N): "; cin>>K;
//	} while(K<=0 || K>=N);
//    if(K <= A.size()) {
//        cout << "Phan tu nho thu " << K << " trong day la: " << A[K - 1] << endl;
//    } else {
//        cout << "Khong c� phan tu nho thu " << K << " trong day" << endl;
//    }
//    
//    return 0;
//}



