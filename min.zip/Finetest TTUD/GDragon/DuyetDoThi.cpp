#include <bits/stdc++.h>
using namespace std;
const char ginp[]="DT.IN2";
int a[101][101]; 
int n, visited[101], Q[101],v, s,sothanhphanLienThong=1, truoc[101];
void init()
{
	freopen(ginp, "r", stdin);
    //Doc du lieu vao
    cin>>n; 
    for (int i=1; i<=n; i++)
   		for (int j=1; j<=n; j++) cin>>a[i][j];
   	//in ma tran ke
   	cout<<"So dinh: "<<n<<"\n";
   	cout<<"Ma tran ke cua do thi:"<<"\n";
   	for (int i=1; i<=n; i++)
   	    { 
		   for (int j=1; j<=n; j++) cout<<a[i][j]<<" ";
   		   cout<<"\n";
   		}
}
void DFS(int u)
{
    cout << u <<" ";//in ra dinh u
//    visited[u] = sothanhphanLienThong;//danh dau dinh da tham
    visited[u] = 1;//danh dau dinh da tham
    for (int v = 1; v <= n; v++)
        if (a[u][v] == 1 && visited[v]==0){
        	truoc[v]=u; DFS(v);
		} 
}
 
void BFS(int u)
{
	int v, dau=1, cuoi=1;
	Q[cuoi]=u; visited[u]=1;
	while (dau<=cuoi)
	{
		v=Q[dau]; dau++;	// lay dinh o dau hang doi ra
		cout << v <<" ";
		for (int j=1; j<=n; j++)
		    if (a[v][j]==1 && visited[j]==0){
				cuoi++; Q[cuoi]=j; visited[j]=1;truoc[j]=v;   // them j vao cuoi hang doi
			}
	}
}

void KTlienthong(){ 
	for (int v = 1; v <= n; v++) visited[v] = 0; 
	sothanhphanLienThong=0; 
	for (int v = 1; v <= n; v++) 
		if (visited[v] == 0) { 
			sothanhphanLienThong++; 
			DFS(v); //BFS(v);
		}
	if (sothanhphanLienThong==1) cout<<"Do thi lien thong"<<endl;
	else{ 
	cout<<"Do thi co "<<sothanhphanLienThong<<" thanh phan lien thong"<<endl;
	for (int i= 1; i<=sothanhphanLienThong; i++){ 
		cout<<"Thanh phan lien thong "<<i<<" gom cac dinh:"<<endl;
		for (int v=1; v<=n; v++)
			if (visited[v]==i) cout<<v<<" ";
			cout<<endl; 
		}
	}
}

void KtrDoThi2Phia(){
    set<int> X = {1};
    set<int> Y;
    while (true)
    {
        set<int> new_Y;
        for (int u : X){	
            for (int v = 1; v <= n; v++){		// xet tung dinh
                if (a[u][v]==1 && Y.find(v) == Y.end())		//  kiem tra xem co mot canh noi tu dinh u den v khong, va v khong thuoc Y
                {
                    new_Y.insert(v);
                }
            }
        }
        if (new_Y.empty() || (X == new_Y && Y == new_Y)){	
            break;
        }
        Y = new_Y;	// sau khi them cac dinh ke voi cac dinh trong X, cap nhat Y = new_Y
        set<int> new_X;
        new_X.insert(1);
        for (int v : Y)	// ta duyet tuong tu voi tap Y moi
        {
            for (int u = 1; u <= n; u++)
            {
                if (a[u][v]==1 && X.find(u) == X.end())
                {
                    new_X.insert(u);
                }
            }
        }
        if (new_X.empty() || (X == new_X && Y == new_X)||X.size() + Y.size() > n){
            break;
        }
        X = new_X;
    }
    
    //Kiem tra X v� Y c� tao th�nh tap dinh kh�ng
//    for (int u : X){
//        for (int v : Y){
//            if (a[u][v] == 0 && a[v][u] == 0)	// khong co canh noi tu dinh u den v
//            {
//                check = false;
//            }
//        }
//    }
//	check = true;
	if(X.size() + Y.size() == n){
//    if(check){
    	cout<<"La do thi 2 phia"<<endl;
    	cout<<"Phia 1:";
    	for (int u : X){
    		cout<<" "<<u;
		}
		cout<<"\nPhia 2:";
		for (int v : Y){
    		cout<<" "<<v;
		}
	}else{
		cout<<"Khong phai la do thi 2 phia"<<endl;
	}
    
}

void TimDuongDi(){
	int start=1,end=5;
	//Khoi tao c�c dinh deu chua tham
	for (int v = 1; v <= n; v++) {
		truoc[v] = 0; visited[v] = 0;
	}
	DFS(s);
//	BFS(s);
	if (visited[end]==0)
		cout<<"\nKhong co duong di tu "<<start<<" den "<<end<<endl;
	else {
		cout<<"\nDuong di tu "<<start<<" den "<<end<<": "<<endl;
		cout<<end;
		int p=end;
		while (truoc[p]!= 0){
			p= truoc[p]; cout<<" <-- "<<p;
		}
	}
	cout<<endl;
}

int main()
{
    init();
    s=1; //dinh bat dau
    //Khoi tao c�c dinh deu chua tham	
   	for (int i = 1; i <= n; i++) visited[i] = 0;
    cout<<"Duyet theo chieu sau bat dau tu dinh "<<s<<": \n";
    DFS(s);
    cout<<"\n";
    
    //Khoi tao c�c dinh deu chua tham	
   	for (int i = 1; i <= n; i++) visited[i] = 0;
    cout<<"Duyet theo chieu rong bat dau tu dinh "<<s<<": \n";
    BFS(s);
    cout<<"\n";
    
//	KTlienthong();
	KtrDoThi2Phia();
//	TimDuongDi();
	
    return 0;
}
