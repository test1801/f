#include<bits/stdc++.h>
using namespace std;

int a[100],b[100];
int m,n;
int s;

void Xet(int &count)
{
	s = 0;
    for (int i = 1; i <= n; i++){
    	if(b[i] == 1){		// Dua vao xau nhi phan de xet tung tong
        	s+= a[i];		//b n�o duoc duyet 1 th� cong a tuong ung vao
//        	cout<<a[i]<<" ";
    		if(s>m) return;		// khi vuot qua tong m thi bo qua
		}	
	}
//	cout<<endl;
    if (s==m) count++;
}

// Ham liet ke xau nhi phan do dai n (Thuat toan quay lui)
void Try(int x, int &count)
{
    for (int j = 0; j <= 1; j++)
    {
        b[x] = j;
		   // ghi nhan trang thai moi
        if (x == n) // sau khi in du 1 xau nhi phan thi ta xet luon xau do
            Xet(count);
        else
            Try(x + 1,count); // tra ve trang thai cu
    }
}

int main(){
	int count =0;
	cout<<"Nhap m = ";
	cin>>m;
	cout<<"Nhap n = ";
	cin>>n;
	for(int i = 1;i<=n;i++){
		cout<<"a["<<i-1<<"] = ";
		cin>>a[i];
	}
	Try(1,count);
	cout<<"Co tat ca "<<count<<" cach phan tich.";
}

