#include<bits/stdc++.h>
using namespace std;
int main(){
	//Bai1:
//	int a,b,c,d;
//	float x=-100;
//	cout<<"Nhap a: "; cin>>a;
//	cout<<"Nhap b: "; cin>>b;
//	cout<<"Nhap c: "; cin>>c;
//	cout<<"Nhap d: "; cin>>d;
//	cout<<"Phuong trinh vua nhap: "<<a<<"x^3 + "<<b<<"x^2 + "<<c<<"x + "<<d<<" = 0";
//	
//	while(a*pow(x,3)+b*pow(x,2)+c*x+d<=0.0000001){
//		x+=0.00001;
//	}
//	cout<<"\nNghiem: "<<x;
	
	//Bai2:
	int k,n;
	cout<<"Nhap do chenh lech k: "; cin>>k;
	cout<<"Nhap so phan tu n: "; cin>>n;
	int a[n];
	for(int i = 1; i<=n;i++){
		cout<<"A["<<i<<"] = ";
		cin>>a[i];
	}
	int count=0;
	for(int i = 1; i <=n;i++){
		for(int j=i+1;j<=n;j++){
			if(k == abs(a[i] - a[j]))
				count++;
		}
	}
	cout<<"Co "<<count<<" cap so chenh lech "<<k;
}
