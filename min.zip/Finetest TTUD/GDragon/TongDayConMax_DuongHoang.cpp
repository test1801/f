#include<bits/stdc++.h>
using namespace std;

int a[101],b[101],m,n;

int find(){
	int d[m+1][n+1];
	for(int i=0;i<=m;i++){
		for(int j=0;j<=n;j++){ 
			if(i==0||j==0) d[i][j]=0;
			else if(a[i-1]==b[j-1]) d[i][j]=d[i-1][j-1]+a[i-1];
			else d[i][j] = max(d[i-1][j],d[i][j-1]);
		}
	}
	return d[m][n];
}
int main(){
	cout<<"Nhap m = "; cin>>m;
	for(int i=0;i<m;i++){
		cout<<"a["<<i+1<<"] = "; cin>>a[i];
	}
	cout<<"Nhap n = "; cin>>n;
	for(int i=0;i<n;i++){
		cout<<"b["<<i+1<<"] = "; cin>>b[i];
	}
	cout<<"Day con co tong lon nhat = "<<find();
}
