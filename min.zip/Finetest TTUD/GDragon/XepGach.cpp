#include<bits/stdc++.h>
using namespace std;

void sapxep(int a[], int n){
	for(int i = 1;i<n;i++){
		for(int j = i+1 ; j<=n ;j++){
			if(a[i]<a[j]){		// giam dan
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}
bool ton_tai_0(int a[], int n){
	bool check = false;
	for(int i = 1; i<=n;i++){
		if(a[i]==0){
			check = true;
			break;
		}
	}
	return check;
}

int main(){
	int n;
	cin>>n;
	int a[n];
	for(int i = 1; i<=n;i++){
		cin>>a[i];
	}
	sapxep(a,n);	//giam dan
//	for(int i = 1; i<=n;i++){
//		cout<<a[i];
//	}
	int count=1;	//xep luon vien gach dau tien -> do cao = 1
	int k_max=a[1];		//k_max: do cung vien gach lon nhat
	if(a[1] == 0){	//TH ca mang = 0
		count = 1;		
	}else{
		for(int i = 2; i<=n;i++){
			if(a[i]!=0){
				count++;
				k_max--;		//so vien gach con lai co the duoc xep len
				if(k_max==0){	//da xep het gach
					break;
				}
			}else if(a[i]==0){	//vien gach dang xet co do cung = 0 ( khong the xep them duoc)
				count++;	// xep vien gach c� do cung = 0 do vao
				break;
			}
			else if(n<=k_max&&!ton_tai_0(a,n)){		// xu li cho TH 6 6 6 6 6
				count=n;
			}
		}
	}
	
	cout<<count;
}

