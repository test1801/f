#include<iostream>
using namespace std; 
int n;
int arr[1001];
int sum = 0;
bool Check(int k){//ham kiem tra tong de cat nhanh
	//int sum = 0;
	//for(int i=1;i<=k;i++){
	//	sum += arr[i];
	//}
	if (sum == n) {
		cout << n << " = " << arr[1];
		for (int i = 2; i <= k; i++) {
			cout <<"+" << arr[i];
		}
		cout << endl;
		return true;
	}
	return false;
}


void Try(int k,int next) {
	for (int i = next; i > 0; i--,sum-=arr[k]) {
		arr[k]=i;
		sum += arr[k];
		if(Check(k)) continue;		// du thi bo qua gia tri i hien tai
		if(k<n)
			Try(k+1,i);		// chua du thi sinh phan tu tiep theo
	}
}

//arr[1] = 5 -> sum = 5 = n --> return true --> bo qua gia tri i = 5

//arr[1] = 4

//arr[1] = 3 -> arr[2] = 2  --> return true--> bo qua so
//			-> arr[2] = 1 --> return false -> khong bi bo qua
//					-> arr[3] = 1


int main() {
	cout << "Nhap n = "; cin >> n;
	Try(1,n);
	return 0;
}
