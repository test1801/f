#include<bits/stdc++.h>
using namespace std;

int main(){
	int n;
	cout<<"Nhap so phan tu: "; cin>>n;
	int a[n];
	cout<<"Nhap mang: "<<endl;
	for(int i = 1; i<=n;i++){
		cout<<"a["<<i<<"] = ";
		cin>>a[i];
	}
	int min = abs(a[1]-a[2]);
	for(int i = 2; i<n;i++){
		for(int j = i+1;j<=n;j++){
			if(abs(a[i] - a[j])<min){
				min = abs(a[i] - a[j]);
			}
		}
	}
	cout<<"Cac cap phan tu ma chenh lech nho nhat trong day: ";
	for(int i = 1; i<n;i++){
		for(int j = i+1;j<=n;j++){
			if(abs(a[i] - a[j]) == min){
				cout<<" ("<<a[i]<<", "<<a[j]<<")";
			}
		}
	}
}
