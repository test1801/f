#include<bits/stdc++.h>
using namespace std;
int a[100],n;

int main(){
	a[0] = 1;
	a[1] = 1;
	cout<<"N = "; cin>>n;
	for(int i = 2; i<=n;i++){
		a[i] = a[i-1] + 2*a[i-2];
	}
	cout<<"So phuong an = "<<a[n];
}

