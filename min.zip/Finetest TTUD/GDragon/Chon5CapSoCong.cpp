#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include<algorithm>
using namespace std;
int n;
int arr[102];
int cnt;
void Find() {
	for (int i = 0; i < n-1; i++) {	// tim so luong cap so cong bat dau tu so dau, den so cuoi
		for (int j = i + 1; j < n; j++) {	// muc dich de tim cac cong boi cua so phia sau so voi so dang xet
			int cb = arr[j] - arr[i];
			int x = arr[j] + cb;
			int y = x + cb;
			int z = y + cb;
			if (binary_search(arr, arr + n, x) && binary_search(arr, arr + n, y) && binary_search(arr, arr + n, z))
				cnt++;
		}
	}
}
int main() {
	//freopen("input.txt", "r", stdin);
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> arr[i];
	}
	sort(arr, arr + n);
	//0 1 2 3 4 5 6 7 8 9 
	//cb = 1
	// x = 2 , y = 3, z = 4 -> cnt = 1
	//cb = 2
	//x =4, y = 6, z= 8 -> cnt
	Find();
	cout << cnt;
	return 0;
}
