#include<bits/stdc++.h>
using namespace std;

int main(){
	int a,b;
	string s;
	stringstream ss;
	cout<<"Nhap a: ";cin>>a ;
	cout<<"Nhap b: "; cin>>b;
	long long c = pow(a,b);
	cout<<c<<endl;
	//VD: 9^10 = 3486784401		=> 486784401
	
	//Cach 1: O(9)
	if(c>pow(10,9))
		ss<< c;
		s = ss.str();
		cout<<"9 chu so cuoi cung: ";
		for(int i = s.length()-9;i<= s.length();i++){
			cout<<s[i];
		}
	}else{
		cout << "So " << c << " kh�ng du 9 chu so." << endl;
	}
	
	// Cach 2:
//	string str = "0";
//    newStr.insert(6, str);
//	int i = 9,m=0; 
//	if(c>=pow(10,9)){
//		cout<<"9 chu so cuoi cung: ";
//		m=c%(long long)(pow(10, 9));
//		cout<<m;
//		}
//	}else{
//		cout << "So " << c << " kh�ng du 9 chu so." << endl;
//	}
	
	// C�ch 3:
//	ss<<c;
//    string numberString = ss.str();		
//
//    if (numberString.length() >= 9) {
//        string m = numberString.substr(numberString.length() - 9);
//        cout << "9 chu so cuoi cua so " << c << " l�: " << m << endl;
//    } else {
//        cout << "So " << c << " kh�ng du 9 chu so." << endl;
//    }

	return 0;
}
