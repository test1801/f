#include<bits/stdc++.h>
#include <unordered_map>
using namespace std;

//unordered_map<long long,long long> a;
const int MAX = 100;
long long F[MAX];

//unordered_map<int, long long> F;

long long f(int n){
	F[0]=0;
	F[1]=1;
	F[2]=2;
	if(n==0||n==1||n==2){
		return F[n];
	}
	if(n%3==0){
	  int k=n/3;
	  return F[2*k]>0?F[2*k]:f(2*k);
	}
	if(n%3==1){
	int k=n/3;
	F[n]=(F[2*k]>0?F[2*k]:f(2*k))+
	  	(F[2*k+1]>0?F[2*k+1]:f(2*k+1));
	}
	if(n%3==2){
	int k=n/3;
	F[n]=(F[2*k]>0?F[2*k]:f(2*k))+
	  	(F[2*k+1]>0?F[2*k+1]:f(2*k+1))+
	  	(F[2*k+2]>0?F[2*k+2]:f(2*k+2));
	}
	return F[n];
}
int main(){
	int  n;
	cout<<"Nhap n = "; cin>>n;
	cout<<"f("<<n<<") = "<<f(n);
}

