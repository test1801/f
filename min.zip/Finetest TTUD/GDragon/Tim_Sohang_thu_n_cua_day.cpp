#include<bits/stdc++.h>
using namespace std;

int findNthTerm(int n) {
    if (n == 0) {
        return 1; // S? h?ng d?u ti�n X(0) = 1
    }

    int term = 0;
    for (int i = 0; i < n; i++) {
        term += (n - i) * (n - i) * findNthTerm(i);
    }
//    term += 1 * findNthTerm(n - 1);

    return term;
}

int main() {
    int n; cout<<"Nhap n = "; cin>>n;
    int nthTerm = findNthTerm(n);

    cout << "So hang thu " << n << " cua day la: " << nthTerm << endl;

    return 0;
}
