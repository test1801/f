#include<bits/stdc++.h>
using namespace std;

//   1    0  	1  
//a[1]  a[2]    a[3]

//101
int a[100],n;
bool b[100];

void print(){
	for(int i = 1;i<=n;i++){
		cout<<a[i];
	}
	cout<<endl;
}


// 1 2 3
// 3

Try(int i){
	for(int j = 0; j<=1; j++){
		if(b[i] == false){
			a[i] = j;
			b[i] = true;
			if(i==n) print();//Dung -> In ra
			else Try(i+1);
			b[i] = false;
		}
		
	}
}

int main(){
	cout<<"Nhap n = "; cin>>n;
	for(int i = )
	Try(1);
}

