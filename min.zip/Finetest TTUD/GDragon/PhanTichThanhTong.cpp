#include<bits/stdc++.h>
using namespace std;

const int MAX = 100;
int a[MAX], n,m,p=0;
bool b[MAX]; 

void print(int k) {
	int sum=0;
	for (int i = 1; i <= n; i++){
		sum+=a[i];
	}
	if(sum==m){
		cout<< m << " = " <<a[1];
		for (int i = 2; i <= n; i++)
			cout<<"+"<<a[i];
		cout << endl;	
	} 
}

void gen(int k) {
	int p=0;
	for (int j = 1; j <= m-p-n+k; j++) {
		a[k] = j;
		p+=a[k];
		if(k==n) {	print(k);
		}
		else gen(k+1);
		p-=a[k];
	}
}

int main() {
	cout<<"Nhap n = "; cin>>m;
	cout<<"Nhap m = "; cin>>n;
	gen(1);
}

