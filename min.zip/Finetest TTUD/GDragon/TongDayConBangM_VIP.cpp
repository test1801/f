#include<bits/stdc++.h>
using namespace std;

int a[100],n,m;

int Count(int sum,int i){
	if(sum == 0) return 1;		// Dieu kien duoc 1 cach
	if(sum < 0) return 0;
	if(i==n) return 0;
	return Count(sum - a[i], i+1) + Count(sum,i+1); // 1 ben la goi dequy(tong giam dan)
													// 1 ben la xet tuong hop khac re ra tu vi tri khong thoa man
}

int main(){
	cout<<"Nhap m = ";
	cin>>m;
	cout<<"Nhap n = ";
	cin>>n;
	for(int i = 0;i<n;i++){
		cout<<"a["<<i<<"] = ";
		cin>>a[i];
	}
	cout<<"Co tat ca "<<Count(m,0)<<" cach phan tich.";	
}

