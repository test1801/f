#include<bits/stdc++.h>
using namespace std;

int main(){
	int n;
	cin>>n;
	int a[n];
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
//	sort(a,a+n);
	sort(a,a+n,greater<int>());	//giam dan
	int max=a[0];		// chon vien them vao
	int space=a[0];		// chon vien day
	int s = 1;		// so luong vien
	for(int i=1;i<n;i++){
		if(space<=0)
			break;
		else{
			max=a[i];
			space--;
			s++;
			if(max<=space)		// cap nhat do cung = vien moi them
				space = max;
		}
	}
	cout<<s;
}

//1 4 1 1
//max = 4 = space, s=1
//max = 1, space = 3, s=2 -> 1<3 ->space = 1
