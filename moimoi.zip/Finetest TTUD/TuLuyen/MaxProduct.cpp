#include<iostream>
using namespace std;
const long long mod = 1000000001;

int main()
{
	int n;
	cin >> n;
	int ans = 0;
	for (int i=1;i<=n; i++)
	{
		ans += (i*i*i) % mod;
	}
	cout << ans;
}

// 4 3 2 1 | 4 2 3 1 | 4 3 1 2
//64 18 6 2 = 82 + 6  + 2 = 90
