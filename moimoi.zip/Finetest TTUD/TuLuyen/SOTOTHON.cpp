#include<bits/stdc++.h>
using namespace std;

long long a,b;

void xuli(long long m,long long n){
	long long sum1,sum2,tmp1,tmp2;
	for(long long i=1;i<=m;i++){
		if(m%i==0)	sum1+=i;
	}
	tmp1 = sum1/m;
	for(long long j=1;j<=n;j++){
		if(n%j==0)	sum2+=j;
	}
	tmp2 = sum2/n;
	if(tmp1>tmp2)	cout<<"So "<<m<<" tot hon so "<<n;
	else if(tmp1==tmp2) cout<<"So "<<m<<" tot nhu so "<<n;
	else cout<<"So "<<n<<" tot hon so "<<m;
}

int main(){
	cin>>a>>b;
	xuli(a,b);
	return 0;
}
