def solve(s):
    last_appear = {}
    dp = [0]*(len(s) + 1)
    dp[0] = 1
    for i in range(1, len(s) + 1):
        dp[i] = dp[i-1] * 2
        if s[i-1] in last_appear:
            dp[i] -= dp[last_appear[s[i-1]]]
        last_appear[s[i-1]] = i-1
    return dp[len(s)] - 1


s = input()
print(solve(s))
