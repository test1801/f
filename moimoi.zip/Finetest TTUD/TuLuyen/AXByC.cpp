#include <bits/stdc++.h>
using namespace std;

int main(){
    int A, B, N;
    cin>>A>>B>>N;
    A = A*A;
    B = B*B;
    long long sum = 0;
    if(A>B) swap(A, B);
    int maxY = N/B;
    for(int i = maxY; i >= 0; i--){
        long long tmp = B*i;
        long long Ax = N - tmp;
        sum += Ax/A + (Ax%A != 0);
    }
    cout<<sum;
}
