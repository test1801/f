#include<bits/stdc++.h>
using namespace std;

int n, arr[100];
bool b[100];
set<vector<int>> CanhTamGiac; // C�c tam gi�c unique

bool KiemTraTamGiacVuongDienTichNhoHonN(){
    int a = arr[1], b = arr[2], c = arr[3];
    int chuvi = a + b + c;
    if((a * a + b * b == c * c || b * b + c * c == a * a || c * c + a * a == b * b) && chuvi <= n){
        return true;
    }
    return false;
}

void Xet(){
    if(KiemTraTamGiacVuongDienTichNhoHonN()){
        vector<int> triangle = {arr[1], arr[2], arr[3]};
        sort(triangle.begin(), triangle.end()); 	// sap xep lai cac canh thi moi biet c� hay chua
        CanhTamGiac.insert(triangle); 	// them bo canh vao set
    }
}

void Try(int i){
    for(int j = 1; j <= n; j++){
        if(b[i] == false){
            b[i] = true;
            arr[i] = j;
            if(i == 3){
                Xet();
            } else {
                Try(i+1);
            }
            b[i] = false; 
        }
    }
}

int main(){
    cin >> n;
    for(int i = 1; i <= 3; i++) b[i] = false;
    Try(1);
    cout << CanhTamGiac.size() << endl;
    return 0;
}
