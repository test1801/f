#include <iostream>
#include <algorithm>
using namespace std;
const int MAX = 6;
int s[MAX] = { 0, 1, 3, 3, 6, 8 };	//start: thoi diem bat dau
int f[MAX] = { 6, 4, 5, 8, 10, 11 };	//finally: thoi diem ket thuc
int a[MAX], e;		// a[i]: mang chua thoi gian cua lich lam 
bool sapxep(int i, int j) { 
	return f[i] < f[j]; 
}
int main() {
	for (int i = 0; i < MAX; i++) a[i] = i;
	sort(a+0, a+MAX, sapxep);
	cout<<"Day cac cuoc hop duoc bo tri: ";
	cout<< a[0];
	int count = 1;
	e = f[a[0]];	//Thoi diem ket thuc
	for (int i = 1; i < MAX; i++)
		if (e <= s[a[i]]) {		//Thoi diem bat dau a[i] > thoi diem ket thuc	
		cout << " " << a[i];
		count++;
		e = f[a[i]];
	}
	cout<<"\nTong so cuoc hop duoc bo tri: "<<count;
}


