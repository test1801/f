#include<bits/stdc++.h>

using namespace std;

int n;

//ep kieu int -> string
string ToString(int number) {
    stringstream ss;
    ss << number;
    return ss.str();
}

//Tach ra kiem tra 0 vs 101
//					01 vs 01
//					010 vs 0


bool ktrlap(string chuoiSauKhiThemI){
	for(int i = 1;i<=chuoiSauKhiThemI.length()/2;i++){
		string str1 = chuoiSauKhiThemI.substr(0,i);		// i phan tu bat dau tu vi tri 0
		string str2 = chuoiSauKhiThemI.substr(i);		// tu i den het chuoi
//		cout<<str1<<" "<<str2<<endl;
		if(str1 == str2){return true;	//bi lap
		}
	}
	return false;	//khong lap
}

//VD: 0101210
void Try(string chuoiHienTai) {
    for (int i = 0; i <= 2; i++) {
    	
        if (chuoiHienTai == "" 
		|| (chuoiHienTai.substr(chuoiHienTai.length() - 1) != ToString(i)  //ktr khong lap 2 phan tu lien tiep
		&& !ktrlap(chuoiHienTai + ToString(i)))) {	// kiem tra tinh trang lap cua chuoi sau khi them kha nang i
			
            if (chuoiHienTai.length() == n) {
            	cout<<chuoiHienTai<<endl;
        		return;
			}	//neu chuoi hien tai du do dai thi in ra
        	else{
        		Try(chuoiHienTai + ToString(i));
			}		// noi them kha nang i vao chuoi hien tai
        }   
    }
}

int main() {
    cout << "Nhap do dai chuoi tam phan: ";
    cin >> n;
    cout << "Cac chuoi tam phan khong lap:\n";
    Try("");
    //===============TEST==============
//	string a = "0101";
//	if(ktrlap(a)){
//		cout<<"Co"<<endl;
//	}else{
//		cout<<"Khong"<<endl;
//	}
    return 0;
}
