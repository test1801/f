#include<bits/stdc++.h>
using namespace std;

int m,n,p,q;
char a[100][100];
bool visited[100][100];

//			 0,1
//	-1,0	(0,0)		1,0
//			 0,-1

//4 4 1 1
//..xx
//x.xx
//..x.
//xx.x

int di[4] = {-1,0,0,1};
int dj[4] = {0,-1,1,0};
bool check = false;

void dfs(int i, int j){
	visited[i][j] = true;
	if(i == m || j == n){
		check = true;
	}
	for(int k = 0; k<4 ; k++){
		int ik = i + di[k];
		int jk = j + dj[k];
		if(ik>=p && ik<=m && jk>=q && jk<=n && a[ik][jk] == '.' && !visited[ik][jk]){
			dfs(ik,jk);
		}
	}
}

int main(){
	cout<<"m = ";cin>>m;
	cout<<"n = ";cin>>n;
	cout<<"p = ";cin>>p;
	cout<<"q = ";cin>>q;
	for(int i =1;i<=m;i++){
		for(int j=1;j<=n;j++){
			cin>>a[i][j];
		}
	}
	memset(visited, false, sizeof(visited));
	dfs(p,q);
	if(check){
		cout<<"YES";
	}else{
		cout<<"NO";
	}
}

