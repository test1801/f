#include<bits/stdc++.h>
using namespace std;

int DodaiDayLonNhat(int a[], int n) {
    int count[1000];

    for (int i = 0; i < n; i++) {
        count[i] = 1;
    }

// 1 2 3 4 6 2 1

    for (int i = 1; i < n; i++) {	// xet tu vi tri 2
        for (int j = 0; j < i; j++) {	//xet nhung phan tu trc vi tri a[i]
            if (a[i] >= a[j]) {	
                count[i] = max(count[i], count[j] + 1); 		// xet tai vi tri a[i]
            }
        }
    }
    int countmax = -99999;
    for(int i = 1;i<n;i++ ){
    	if(countmax<count[i]){
    		countmax = count[i];
		}
	}
    int kq = countmax;
    return kq;
}

int main() {
    int n;
    cout << "Nhap so phan tu n= ";
    cin >> n;

    int a[1000];
    for (int i = 0; i < n; i++) {
    	cout<<"Nhap phan tu thu "<<i+1<<": ";
        cin >> a[i];
    }
    cout << "Do dai cua day con khong giam dai nhat la: " << DodaiDayLonNhat(a,n) << endl;

    return 0;
}
