#include<bits/stdc++.h>
using namespace std;

void swap_array(int *a,int n){
	for(int i = 1; i<n;i++){
		for(int j = i+1;j<=n;j++){
			if(a[i]>a[j]){
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}

int main(){
	int n;
	cout<<"Nhap so phan tu: "; cin>>n;
	int a[n];
	cout<<"Nhap mang: "<<endl;
	for(int i = 1; i<=n;i++){
		cout<<"a["<<i<<"] = ";
		cin>>a[i];
	}
	swap_array(a,n);
//	cout<<"Mang sau khi sap xep:";
//	for(int i = 1; i<=n;i++){
//		cout<<" "<<a[i];
//	}
	int k;
	do{
		cout<<"Nhap k (k<n): "; cin>>k;
	}while (k>=n);
	
	int min = 99999,vitri;
	for(int i = 1; i<=n-k;i++){
		if(abs(a[i] - a[i+k-1])<min){
			min = abs(a[i] - a[i+k-1]);
			vitri = i;
		}
	}
	cout<<"Mang duoc chon: ";
	for(int i = vitri; i<=vitri+k-1;i++){
		cout<<" "<<a[i];
	}
	cout<<"\nChenh lech giua so lon nhat va nho nhat trong day k phan tu: "<<min;
}
