#include<bits/stdc++.h>

using namespace std;

struct CongViec {
	int index;
    int thoiDiemDeadline;
    int diemThuong;
};


bool soSanhCongViec(CongViec a, CongViec b) {
    return a.diemThuong > b.diemThuong;
}

void lichTrinhThucHien(vector<CongViec>& congViec,vector<CongViec>& congViecBanDau) {
	int time = 0;
    sort(congViec.begin(), congViec.end(), soSanhCongViec);	// Sap lai day lich trinh theo diem thuong

    vector<bool> oCongViec(congViec.size(), false);	// trang thai tung cong viec(da duoc chon hay chua)
    vector<int> ketQua;

    for (int i = 0; i < congViec.size(); i++) {
    	if(time+1<=congViec[i].thoiDiemDeadline){	//kiem tra dieu kien deadline
    		time++;	// khi them 1 cong viec thi time +1
    		ketQua.push_back(congViec[i].index);
		}
    }
	
    // In lich trinh
    cout << "Lich trinh thuc hien: ";
    for (int i = 0; i < ketQua.size(); i++) {
        cout << ketQua[i] << " ";
    }

    // Tinh tong diem thuong
    int tongDiemThuong = 0;
    for (int i = 0; i < ketQua.size(); i++) {
        tongDiemThuong += congViecBanDau[ketQua[i]].diemThuong;
    }

    cout << "\nTong diem thuong: " << tongDiemThuong << endl;
}

int main() {
    int soCongViec = 5;
    vector<CongViec> congViec = {{0,2,100}, {1,1,19}, {2,2,27},{3,1,25},{4,3,15}};
	vector<CongViec> congViecBanDau = {{0,2,100}, {1,1,19}, {2,2,27},{3,1,25},{4,3,15}};
    lichTrinhThucHien(congViec,congViecBanDau);
    return 0;
}
