#include<bits/stdc++.h>
using namespace std;

int a[100] = {2,3,4,-6,5,4,-8,10,9,7};
int b[100] = {1,3,4,-6,5,4,-8,7};
int p = 9, q = 7;


int S(int p, int q){
	if(p==0 || q==0){	// chay het day a hoac b
		return 0;
	}
	if(a[p] == b[q]){
		return S(p-1,q-1) + 1;
	}else{
		return max(S(p-1,q),S(p,q-1));
	}
	
}

int main(){
	cout<<"Day con chung dai nhat: "<<S(p,q);
}

