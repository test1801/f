#include <iostream>
#include <map>
using namespace std;

map<long long, long long> nhap;
long long fibo(long long n)
{
	long long k = n/3;
	if(n == 0) return 0;
	if(n == 1) return 1;
	if(n == 2) return 2;
	if(n%3 == 0){
		if(nhap.count(n)==0)
			nhap[n] = fibo(2*k);	
	}
	if(n%3==1){
		if(nhap.count(n)==0)
			nhap[n] = fibo(2*k) + fibo(2*k+1);
	}
	if(n%3==2){
		if(nhap.count(n)==0)
			nhap[n] = fibo(2*k) + fibo(2*k+1) +fibo(2*k+2);
	}	
		return nhap[n];
}

int main() {
  long long n;
  cout<< "Nhap n = ";
  cin >> n;
  cout<<"f("<< n <<") = " << fibo(n);
  return 0;
}

