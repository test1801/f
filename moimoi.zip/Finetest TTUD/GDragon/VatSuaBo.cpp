#include<iostream>
#include<algorithm>

using namespace std;

const int MAX = 4;
int b[MAX] = {2,1,4,3};
int a[MAX], e, res = 0;

bool sx(int i, int j){
//	cout<<"i = "<<i<<" | j = "<<j<<endl;
	return b[i] > b[j];
}

int main(){
	for(int i=0; i<MAX; i++){
		a[i] = i;
	}
	sort(a+0, a+MAX, sx);
//	e = b[a[0]];
	res = b[a[0]];
	cout<<"Thu tu vat: "<< a[0]+1;
	
	for(int i=1; i<MAX; i++){
		int tmp = b[a[i]] - i;
		if(tmp>0) {
			cout<<" "<<a[i]+1;
			res+=tmp;
		}else cout<<" "<<a[i]+1;
	}
	cout<<"\nKet qua: " <<res;
	return 0;
}
