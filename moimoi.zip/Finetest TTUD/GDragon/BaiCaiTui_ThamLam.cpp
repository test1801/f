#include<bits/stdc++.h>
using namespace std;

//uu tien ti so gia tri chia trong luong lon
//y tuong la chia xem gia cua 1 can trong luong

//gia tri 		20	16	8
//trong luong:  14 	10 	6
//uu tien 1kg vat: 20/14 ; 16/10 ; 8/6
//					1.43	1.6	1,3
//					xep lai la 2	1	3
// 

int w=19;
const int N=4;
float gt[N]={0,20,16,8};
float tl[N]={0,14,10,6};
int a[N],total=0;
bool sapxep(int i, int j) { 
//	cout<<gt[i]/tl[i]) <<" | "<<gt[j]/tl[i];
	return (gt[i]/tl[i]) > (gt[j]/tl[j]); 
}
//1 0 2
int main(){
	for (int i = 1; i <= N; i++) a[i] = i;
	sort(a+0, a+N, sapxep);
	total = gt[a[1]];//viec tot nhat
	int tui=19-tl[a[1]];//trong luong con lai
	cout<<a[1];
	for (int i = 1; i < N; i++)
		if (tui >= tl[a[i]]) {//suc chua van con lon hon trong luong thu k
			cout << " " << a[i];
			total += gt[a[i]];
			tui-=tl[a[i]];//giam trong luong con lai
		}
	cout<<"\nTong gia tri lon nhat lay duoc: "<<total;
	
}

