#include<bits/stdc++.h>
using namespace std;

int main(){
	long long a=0,b=1,c=0,k;
	 cin>>k;
	while(c<=k){
		c = a + b;
		a=b;
		b=c;
	}
	cout<<c;
}
