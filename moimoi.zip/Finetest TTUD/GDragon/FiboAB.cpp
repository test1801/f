#include<bits/stdc++.h>
using namespace std;

string fibo(int n,string a){
	string A = "A";
	string B = "B";
	string C;
	while(n>2){
		string C = A.append(B);
		A = B;
		B = C;
		n--;
	}
	return C;
}

int main(){
	int m,n;
	cout<<"Nhap M = "; cin>>m;
	cout<<"Nhap N = "; cin>>n;
	string a="";
	cout<<fibo(n,a);
	a = fibo(n,a);
	cout<<"Tu thu M cua chuoi thu N"<<a[m];
}

