#include<bits/stdc++.h>
using namespace std;

int diff(vector<int> a,int n){
	int min_diff=999999;
	for(int i=0;i<n-1;i++){
		if(min_diff > abs(a[i] - a[i+1]))
			min_diff = abs(a[i] - a[i+1]);
	}
	return min_diff;
}


int main(){
	vector<int> a;
	int n,m;
	cout<<"Nhap n = ";
	cin>>n;
	for(int i = 0;i<n;i++){
		cout<<"a["<<i<<"] = ";
		cin>>m;
		a.push_back(m);
	}
	sort(a.begin(),a.end());
	
	cout<<"Chenh lech nho nhat: "<<diff(a,n);
}

