#include <iostream>
#include <algorithm>
using namespace std;
const int MAX = 10000;
int a[MAX],n,m,p;
int b[MAX];

void print(int i){
	cout << m <<" = ";
	for(int j = 0;j<i;j++){
		cout << a[j];
			if(j!=i-1)
				cout << "+";
	}
		cout << endl;
}

void find(int n,int i){
	if(n < 0) return;
	if(n == 0){
		print(i); return;
	}
	int p = (i == 0) ?  n : a[i - 1];		// loai TH so be + so to ( VD:  5 = 2+3	)
    for (int k = p; k >=1; k--) {
        a[i] = k;
        find(n-a[i], i + 1);
    }
}

// n = 5, i = 0
//a[0] = 5
//
//k = 4
//a[0] = 4
//n=1 ,i = 1
//p = 4  -> a[1] = 4 bo qua 1-4<0
//		-> a[1] = 3 bo qua
//		-> a[1] = 2 bo qua
//		-> a[1] = 1 -> 1-1 = 0 -> in ra 4+1
//
//k=3
//a[0] = 3
//n = 2, i = 2


int main(){
	cout << "Nhap n = "; cin >> n;
	m = n;	// giu lai gia tri n ban dau
	find(n,0);
	return 0;
}
