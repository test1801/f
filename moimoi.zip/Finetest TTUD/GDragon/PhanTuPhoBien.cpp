#include<bits/stdc++.h>
using namespace std;

int PhanTuPhoBien(const vector<int>& A, int start, int end) {
    if (start == end) {
        return A[start];
    } else {
        int mid = (start + end) / 2;

        int PhanTuPhoBien_left = PhanTuPhoBien(A, start, mid);
        int PhanTuPhoBien_right = PhanTuPhoBien(A, mid + 1, end);

        int leftCount = 0;
        int rightCount = 0;

        for (int i = start; i <= end; ++i) {
            if (A[i] == PhanTuPhoBien_left) {
                ++leftCount;		// �em so lan xuat hien cua phan tu pho bien ben trai
            } else if (A[i] == PhanTuPhoBien_right) {
                ++rightCount;	// �em so lan xuat hien cua phan tu pho bien ben phai
            }
        }

        int n = (end - start + 1) / 2;

        if (PhanTuPhoBien_left == PhanTuPhoBien_right && leftCount + rightCount >= n) { // phan tu do phai nhieu hon 1 nua so luong phan tu trong day
            return PhanTuPhoBien_left;
        } else {
            return (leftCount > rightCount) ? PhanTuPhoBien_left : PhanTuPhoBien_right;
        }
    }
}

int main(){
	vector<int> a;
	int n,m;
	cout<<"Nhap n = ";
	cin>>n;
	for(int i = 0;i<n;i++){
		cout<<"a["<<i<<"] = ";
		cin>>m;
		a.push_back(m);
	}	
	cout << "Phan tu xuat hien pho bien nhat trong mang A la: " << findMostFrequentElement(a, 0, n-1) <<endl;
}

