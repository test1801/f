#include <iostream>
using namespace std;

int const MAX = 10000;
int a[MAX][MAX];
int n;

void print(){
	int sum = 0;
	for(int i = 1; i<=n; i++){
		for(int j = 1; j<=n; j++){
			if(a[i][j] != 0)
				sum = sum + a[i][j];		// cong tat ca gia tri trong mang lai
		}
	}
	cout<<sum;
}
void gen(int line, int stt){
	if(line > n){		// dieu kien dung la sinh ra du n hang
		print(); return;
	}
	else if(line == 1 || stt == line){		// duong cheo chinh. cung la dieu kien ket thuc 1 hang de chuyen sang hang khac
		a[line][stt] = 1;
		gen(line+1, 1);	// chuyen sang dong tiep theo
	}
	else if(stt == 1){	// so dau tien trong hang luon = 1
		a[line][stt] = 1;
		gen(line, stt+1);	// chuyen sang so tiep theo trong hang
	}
	else{
		a[line][stt] = a[line-1][stt-1] + a[line-1][stt];
		//VD:
		//1 2 1			--> 1 2		--> dang xet so 3 nen vi tri so 3 la line,stt
		//1 3 3 1			  3 
		//
		//	line-1, stt-1		line-1,stt
		//						line,stt
		gen(line, stt+1);		// chuyen sang so tiep theo trong hang
	}
}
int main(){
	cout<<"Nhap N: ";cin>>n;
	n=n+1;
	gen(1,1);
}

