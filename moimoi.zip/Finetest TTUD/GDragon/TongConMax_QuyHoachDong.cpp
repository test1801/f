#include<bits/stdc++.h>
using namespace std;

int a[100] = {2,3,4,-6,5,4,-8,10,9,7};
int s[100], n=10;

int main(){
	int max = -999999;
	for(int i = 0; i<n;i++){
		cout<<a[i]<" ";
	}
	s[0] = a[0];
	for(int i=1; i<n; i++){
		s[i] = s[i-1] <= 0 ? a[i] : a[i] + s[i-1];
	}
	for(int i = 0;i<n;i++){
		if(s[i]>max){
			max = s[i];
		}
	}
	cout<<"Tong day con lon nhat: "<<max;
}

