#include<bits/stdc++.h>
using namespace std;

int a[100],x;

int P(int n){
	if(n==0) return a[0];
	return P(n-1)*x + a[n];
}

int main(){
	int n;
	cout<<"Nhap n = ";cin>>n;
	for(int i = 0;i<=n;i++){
		cout<<"a["<<i<<"] = ";
		cin>>a[i];
	}
	cout<<"Nhap x = "; cin>>x;
	cout<<"P"<<n<<"("<<x<<") = "<<P(n);
}

