#include<bits/stdc++.h>

using namespace std;

int binary_search2(int arr[], int l, int r, int x) {
	while (l <= r) {
		int m = l + (r - l) / 2;
		if (arr[m] == x) return m;
		if (arr[m] < x) l = m + 1;
		else r = m - 1;
	}
	return -1;
}

int binary_search(int arr[], int l, int r, int x) {
	if (r < l) return -1;
	int mid = l + (r - l) / 2;
	// t�m th?y ? gi?a
	if (arr[mid] == x) return mid;
	// t�m ? n?a tru?c
	if (arr[mid] > x)
	return binary_search(arr, l, mid - 1, x);
	// t�m ? n?a sau
	return binary_search(arr, mid + 1, r, x);
}

int interpolation_search(int a[], int l, int r, int x) {
	while (l <= r) {
		int m = l + (x - a[l]) * ((r - l) / (a[r] - a[l]));
		if (a[m] == x) return m;
		if (a[m] < x) l = m + 1;
		else r = m - 1;
	}
	return -1;
}


int main (){
	clock_t begin = clock();
	long long n;
	cout<<"Nhap so phan tu: "; cin>>n;
	int a[n];
	long long i;
	for(i =0; i <n;i++){
		a[i] = i;
	}
	int x;
	cout<<"Nhap so can tim: "; cin>>x;
//	cout<<"Vi tri can tim: "<<binary_search(a,0,n-1,x);
//	cout<<"Vi tri can tim: "<<binary_search2(a,0,n-1,x);
	cout<<"Vi tri can tim: "<<interpolation_search(a,0,n-1,x);
	clock_t end = clock();
	cout<<"\nTime run: "<<(float)(end-begin)/CLOCKS_PER_SEC<<" s"<<endl;
	return 0;
}

