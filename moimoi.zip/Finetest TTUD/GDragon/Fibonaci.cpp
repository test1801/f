#include<bits/stdc++.h>
using namespace std;

//Day Fibonacci: 0 1 1 2 3 5 8 13 21 34 55 89 144

int Fibo(int n){
	if(n==0) return 0;
	if(n==1) return 1;
	return Fibo1(n-1) + Fibo1(n-2);
}

int Fibo(int a[], int n){
	a[0] = 0;
	a[1] = 1;
	for(int i=2;i<= n;i++){
		a[i] = a[i-1] + a[i-2];
	}
	return a[n];
}

int Fibo(int a,int b, int n){
	int i = 2,c;
	if(n==0) return a;
	if(n==1) return b;
	while(i<=n){
		c = a + b;
		a = b;
		b = c;
		i++;
	}
	return c;
}

int main(){
	int n,Fn;
	cout<<"Nhap n: "; cin>>n;
	int k[n];
	
	//Cach 1: De quy
//	Fn = Fibo(n);
	//Cach 2: Array
//	Fn = Fibo(k,n);
	//Cach 3: 
	Fn = Fibo(0,1,n);
	
	cout<<"So Fibonacci thu "<< n<<": "<<Fn;
	return 0;
}
