#include<bits/stdc++.h>
using namespace std;

const int MAX = 100;
int a[MAX], n, m;


bool ktr_sochan_nhieuhon(){
	int count_sochan = 0, count_sole = 0;
	for (int i = 1; i <= n; i++){
		if(a[i] %2==0) count_sochan++;
		else count_sole++;
	}
	if(count_sochan>count_sole) return true;
	else return false;
}

bool ktr_1_so_chiahet5(){
	for (int i = 1; i <= n; i++){
		if(a[i] %5==0) return true;
	}
	return false;
}

bool ktr_capso_chiahet8(){
	for (int i = 1; i < n; i++){
		for(int j = i+1 ; j<=n;j++){
			if((a[i]*a[j])%8==0){
				return true;
			}
		}
	}
	return false;
}

bool ktr_solonhon13(){
	int count=0;
	for (int i = 1; i <= n; i++){
		if(a[i]>13) count++;
	}
	if(count>3) return false;
	else return true;
}

void print(int n) {
	if(ktr_sochan_nhieuhon()
		&&ktr_1_so_chiahet5()
		&&ktr_capso_chiahet8()
		&&ktr_solonhon13()){
			for (int i = 1; i <= n; i++) {
				cout << a[i]<<" ";
			}
			cout<<endl;
	}
	 
}

void gen(int k) {
	for (int j = a[k-1] + 1; j <= m-n+k; j++) {
		
		a[k] = j; 
		if(k==n) {	print(n);
		}
		else gen(k+1);
		
	}	
}
int main() {
	n = 5; m = 20; a[0] = 0;
	gen(1);
}

