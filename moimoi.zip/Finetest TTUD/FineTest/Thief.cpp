#include<iostream>
#include<algorithm>
using namespace std;
const int MAX = 3;
float Cs[MAX] = { 20,16,8 };
float Ws[MAX] = { 14,10,6 };
float tiso[MAX];
int a[MAX];
bool sapxep(int i, int j) { return tiso[i] > tiso[j]; };
int main() {
	int N; int w;
	cout << "Enter N: ";
	cin >> N;
	cout << "Enter w: "; cin >> w;
	for (int i = 0; i < MAX; i++) {
		a[i] = i;
		tiso[i] = Cs[i] / Ws[i];
	}
	sort(a + 0, a + MAX, sapxep);
	float weight = 0;
	int total = 0;
	cout << "Lay cac do vat sau:";
	for (int i = 0; i < MAX; i++) {
		weight += Ws[a[i]];
		if (weight <= w) {
			cout <<" " << a[i];
			total += Cs[a[i]];
		}
		else
			weight -= Ws[a[i]];
	}
	cout << "\nTong gia tri lay duoc: " << total;
	return 0;
}