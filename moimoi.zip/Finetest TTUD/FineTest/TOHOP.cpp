#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
int n = 10;
int m = 3;
int arr[101];
int cnt = 0;
int index = 0;
int dem = 0;
void Xuat() {
	for (int i = 0; i < m; i++) {
		cout << arr[i] << " ";
	}
	cout << endl;
}
void Try(int k,int next) {
	cnt++;

	for (int i = next; i < n; i++) {
		dem++;
		arr[k] = i;
		if (k == m-1) {
			Xuat();
		}
		else
			Try(k + 1,i+1);
	}
}

int main() {
	cout << "Nhap N: "; cin >> n;
	cout << "Nhap M: "; cin >> m;
	int k = 0;
	Try(k,0);
	cout << cnt;
	return 0;
}