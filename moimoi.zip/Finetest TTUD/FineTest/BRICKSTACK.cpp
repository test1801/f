#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
void ShowArray(int arr[], int n) {
	for (int i = 0; i < n; i++) {
		cout << arr[i] << " ";
	}
	cout << endl;
}
void BubbleSort(int arr[], int n, int type) {
	int temp;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n - 1 - i; j++) {
			if (arr[j] * type > arr[j + 1] * type) {
				temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		}
	}
}
int main() {
	freopen("input.txt", "r", stdin);
	int arr[10001];
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin>>arr[i];
	}
	BubbleSort(arr, n, -1);

	int space = arr[0];
	int size = 1;
	int max = arr[0];
	for (int i = 1; i < n; i++) {
		if (space <= 0)
			break;
		else {
			max = arr[i];
			size++;
			space--;
			if (max <= space)
				space = max;
		}
	}
	cout << size;
	//ShowArray(arr, n);
	return 0;

}