#include<iostream>
using namespace std;
int cnt = 0;
int k;
int arr[1001];
int sum = 0;
bool Xuat(int n) {
	if (sum == k) {
		cnt++;
		//for (int i = 1; i <= n; i++) {
		//	cout << arr[i] << " ";
		//}
		//cout << endl;
		return false;
	}
	return true;
}
void Try(int n,int next) {
	for (int i = next; i>0 ; i--) {
		arr[n] = i;
		sum += arr[n];
		if (Xuat(n)) {
				Try(n + 1, k - sum >= i ? i - 1 : k - sum);
		}
		sum -= arr[n];
	}
}
int main() {
	cout << "Nhap k = "; cin >> k;
	Try(1,k-1);
	cout << "Co tat ca " << cnt << " cach phan tich.";
	return 0;
}