#include<iostream>
#include<vector>
using namespace std;
int n;
int a[1002];
int Max() {


    int lis[1002];
    for(int i=0;i<n;i++){
        lis[i]=1;
    }
    for (int i = 1; i < n; ++i) {
        for (int j = 0; j < i; ++j) {
            if (a[i] > a[j] && lis[i] < lis[j] + 1) {
                lis[i] = lis[j] + 1;
            }
        }
    }

    int max_length = 0;

    for(int i=0;i<n;i++) {
        if(lis[i]>max_length) {
            max_length = lis[i];
        }
    }
    return max_length;
}

int main(){
    cout<<"Nhap so phan tu n= ";cin>>n;
    for(int i=0;i<n;i++){
        cout<<"Nhap phan tu thu"<<i+1<<": ";cin>>a[i];
    }
    cout<<"Do dai day con khong giam dai nhat: "<<Max();
    return 0;
}