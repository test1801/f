#include<iostream>
using namespace std;
int arr[1001];
bool dd[1001];
void Xuat() {
	int sum = arr[1];
	for (int i = 2; i <= 9; i++) {
		sum += i % 2 == 0 ? arr[i] : -arr[i];
	}
	if (sum == 23)
	{
		for (int j = 1; j <= 9; j++) {
			cout << arr[j] << " ";
		}
		cout << endl;
		//return;
	}
}
void Hoanvi(int k) {
	if (k >9) {
		Xuat();
		return;
	}
	for (int i = 1; i <= 9; i++) {
		if (dd[i]==false) {
			dd[i] = true;
			arr[k] = i; Hoanvi(k + 1);
			dd[i] = false;
		}
	}
}
int main() {
	for (int i = 1; i <= 9; i++) {
		dd[i] = false;
	}
	Hoanvi(1);
	return 0;
}