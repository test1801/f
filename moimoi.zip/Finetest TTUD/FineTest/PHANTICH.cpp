#include<iostream>
using namespace std;
int arr[1001];
bool dd[1001];
int m, n;
void Xuat() {
	int sum = 0;
	for (int i = 1; i <= n; i++) {
		sum += arr[i];
	}
	if (sum == m) {
		for (int i = 1; i <= n; i++) {
			cout << arr[i] << " ";
		}
		cout << endl;
	}
}
void Hoanvi(int k) {
	if (k > n) {
		Xuat();
		return;
	}
	for (int i = 1; i <= m; i++) {
		arr[k] = i; Hoanvi(k + 1);
	}
}
int main() {
	cout << "Nhap M N: ";
	cin >> m >> n;
	Hoanvi(0);
	return 0;
}
