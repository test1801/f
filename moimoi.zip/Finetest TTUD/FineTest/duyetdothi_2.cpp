#include <bits/stdc++.h>
using namespace std;
const char ginp[]="input.txt";
int a[101][101]; 
int n, visited[101], Q[101],v;
int sotplt= 1;
int truoc[101];
set<int> v1, v2;
int dd[101];
void init()
{
	freopen(ginp, "r", stdin);
    cin>>n; 
    for (int i=1; i<=n; i++)
   		for (int j=1; j<=n; j++) cin>>a[i][j];
   	
   	//in ma tran ke
   	cout<<"So dinh: "<<n<<"\n";
   	cout<<"Ma tran ke cua do thi:"<<"\n";
   	for (int i=1; i<=n; i++)
   	    { 
		   for (int j=1; j<=n; j++) cout<<a[i][j]<<" ";
   		   cout<<"\n";
   		}
	
	
}
void DFS(int u)
{
    // cout << u <<" ";//in ra dinh u
    visited[u] = sotplt;//danh dau dinh da tham
    for (int v = 1; v <= n; v++)
        if (a[u][v] == 1 && visited[v]==0){
			truoc[v]=u;
			DFS(v);
		} 
			
}
 
void BFS(int u)
{
	int v, dau=1, cuoi=1;
	Q[cuoi]=u; visited[u]=sotplt;
	while (dau<=cuoi)
	{
		v=Q[dau]; dau++;
		// cout << v <<" ";
		for (int j=1; j<=n; j++)
		    if (a[v][j]==1 && visited[j]==0){
				truoc[j]=u;
				cuoi++; Q[cuoi]=j; visited[j]=sotplt; 
			} 

	}
}

void timduongdi(){
	int s=1,t=6;
	
	for(int i=1;i<=n;i++){
		visited[i]=0;
	}
	//DFS(s);
	BFS(s);
	if(visited[t]==0){
		cout<<"Khong co duong di tu "<<s<<" den "<<t;
	}else{
		cout<<"Co duong di tu "<<s<<" den "<<t<<":"<<endl;
		cout<<t;
		int j=t;
		while (truoc[j]!=s)
			{
				j=truoc[j];
				cout<<" <-- "<<j;
			}
		cout<<" <-- "<<s;
	}
}

void ktralienthong(){
	for(int i=1;i<=n;i++){
		visited[i] = 0;
	}
	for(int i=1;i<=n;i++){
		if(visited[i]==0){
			sotplt++;
			DFS(i);
		}
		
	}
	if(sotplt==1){
		cout<<"\nDay la do thi lien thong";
	}else{
		cout<<"\nDo thi co "<<sotplt<<" thanh phan lien thong \n";
	}
	for(int k=1;k<=sotplt;k++){
		cout<<"\nThanh phan lien thong thu "<<k<<" gom cac dinh :";
		for(int i=1;i<=n;i++){
			if(visited[i]==k){
				cout<<i<<" ";
			}
		}
	}
}
void Ktradothi2phia(){
    for (int i = 1; i <= n; i++)
    {
        dd[i] = 0;
    }

    v1.insert(1);
    dd[1] = 1;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (a[i][j] == 1)
            {
                if (dd[i] == 1)
                {
                    v2.insert(j);
                    dd[j] = 2;
                }
                else if (dd[i] == 2)
                {
                    v1.insert(j);
                    dd[j] = 1;
                }
            }
        }
    }
    bool flag = 0;
    for (int x1 : v1)
    {
        for (int x2 : v2)
        {
            if (x1 == x2)
            {
                flag = 1;
                break;
            }
        }
    }
    if (flag == 1)
    {
        cout << "Do thi Khong phai 2 phia";
    }
    else
    {
        cout << "Do thi 2 phia" << endl;
        cout << "V1 : ";
        for (int x : v1)
        {
            cout << x << " ";
        }
        cout << "\nV2: ";
        for (int x : v2)
        {
            cout << x << " ";
        }
    }
}

int main()
{
    init();
    //timduongdi();
	Ktradothi2phia();
    //dinh bat dau
    //Khoi tao c�c dinh deu chua tham	
//   	for (int i = 1; i <= n; i++) visited[i] = 0;
//    cout<<"Duyet theo chieu sau bat dau tu dinh "<<s<<": \n";
//    DFS(s);
//    cout<<"\n";
    
    //Khoi tao c�c dinh deu chua tham	
//   	for (int i = 1; i <= n; i++) visited[i] = 0;
//    cout<<"Duyet theo chieu rong bat dau tu dinh "<<s<<": \n";
//    BFS(s);
    // ktralienthong();
	// set<int> rs = keDinh(s);
	// // auto it = rs.begin();
	// // for(int i=1;i<n;i++){
	// // 	it++;
	// // }
	// // cout<<*it;
	// for (auto x: rs) {
    //     cout << x << endl;
    // }

    return 0;
}
