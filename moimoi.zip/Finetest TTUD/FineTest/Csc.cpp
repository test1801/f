#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include<algorithm>
using namespace std;
int n;
int arr[102];
int cnt;
void Find() {
	for (int i = 0; i < n-1; i++) {
		for (int j = i + 1; j < n; j++) {
			int cb = arr[j] - arr[i];
			int x = arr[j] + cb;
			int y = x + cb;
			int z = y + cb;
			if (binary_search(arr, arr + n, x) && binary_search(arr, arr + n, y) && binary_search(arr, arr + n, z))
				cnt++;
		}
	}
}
int main() {
	//freopen("input.txt", "r", stdin);
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> arr[i];
	}
	sort(arr, arr + n);
	Find();
	cout << cnt;
	return 0;
}