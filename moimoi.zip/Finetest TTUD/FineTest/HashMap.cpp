#include<iostream>
using namespace std;
class HashMap {
public:
	int value0[99999999];
	int value1[99999999];
	int value2[99999999];
	HashMap() {
		value0[0] = 0;
		value1[0] = 1;
		value2[0] = 2;
	}
	int HashTable(int key) {
		return key / 3;
	}
	void Add(int key,int value) {
		int index = HashTable(key);
		if (key % 3 == 0) {
			value0[index] = value;
		}
		else if (key % 3 == 1) {
			value1[index] = value;
		}
		else {
			value2[index] = value;
		}
	}
	bool CheckExist(int key) {
		if (key <= 2)
			return true;
		int index = HashTable(key);
		if (key % 3 == 0) {
			return value0[index] == 0 ? false : true;
		}
		else if (key % 3 == 1) {
			return value1[index] == 0 ? false : true;
		}
		else {
			return value2[index] == 0 ? false : true;
		}
	}
	int Value(int key) {
		if (key == 2)
			return 2;
		if (key == 1)
			return 1;
		if (key == 0)
			return 0;
		int index = HashTable(key);
		if (key % 3 == 0) {
			return value0[index];
		}
		else if (key % 3 == 1) {
			return value1[index];
		}
		else {
			return value2[index];
		}
	}
};
HashMap* F = new HashMap();

long long f(long long n) {
	if (n <= 2)
		return F->Value(n);
	int k = n / 3;
	if (n % 3 == 0) {
		F->Add(n, F->CheckExist(2 * k)==true ? f(2*k) : F->value0[2 * k]);
	}
	if (n % 3 == 1) {
		F->Add(n, (F->CheckExist(2 * k) == true ? f(2 * k) : F->value0[2 * k]) + (F->CheckExist(2 * k + 1) == true ? f(2 * k + 1) : F->value0[2 * k + 1]));
	}
	if (n % 3 == 2) {
		F->Add(n, (F->CheckExist(2 * k) == true ? f(2 * k) : F->value0[2 * k]) + (F->CheckExist(2 * k + 1) == true ? f(2 * k + 1) : F->value0[2 * k + 1]) + (F->CheckExist(2 * k+2) == true ? f(2 * k+2) : F->value0[2 * k+2]));
	}
	return F->Value(n);

}
int main() {
	long long n;
	cout << "Nhap n = ";
	cin >> n;
	cout << "f(" << n << ") = " << f(n);

	return 0;
}