#include<iostream>
#include<algorithm>
using namespace std;
const int MAX = 5;
int D[MAX] = { 2,1,2,1,3 };
int P[MAX] = { 100,19,27,25,15 };
int a[MAX];
bool sapxep(int i, int j) { return P[i] > P[j]; };
int main() {
	bool dd[MAX];
	for (int i = 0; i < MAX; i++) {
		a[i] = i;
		dd[i] = false;
	}
	sort(a + 0, a + MAX, sapxep);
	cout << "Thu tu deadline: ";;
	int total = 0;
	for (int time = 0,j=0; j < MAX; j++) {
		if (time+1  <= D[a[j]]) {
			dd[j] = true;
			cout << " " << a[j];
			total += P[a[j]];
			time++;
		}
	}
	for (int i = 0; i < MAX; i++) {
		if (dd[i] == false)
			cout << " " << a[i];
	}

	cout << "\nTong tien thuong lon nhat la: " << total;
	return 0;
}