#include<iostream>
using namespace std;
int n;
int arr[1001];
void Xuat() {
	for (int i = 0; i <= n; i++) {
		cout << arr[i] << " ";
	}
	cout << endl;
}
void Try(int k) {
	if (k > n) {
		Xuat();
		return;
	}
	for (int i = 0; i <= 2; i++) {
		arr[k] = i; Try(k + 1);
	}
}
int main() {
	cout << "Nhap N = ";
	cin >> n;
	Try(0);
	return 0;
}